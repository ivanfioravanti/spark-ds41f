#if defined(_MSC_VER) && !defined(__clang__) && _MSC_VER < 1940
#define _tl_orig_alignas alignas
#define alignas(N) _tl_orig_alignas((N) <= 64 ? (N) : 64)
#include <cuda.h>
#undef alignas
#define alignas _tl_orig_alignas
#endif
#include <math_constants.h>
#include <tl_templates/cuda/reduce.h>
#include <tl_templates/cuda/scan.h>
#include <tl_templates/cuda/ldsm.h>
#include <tl_templates/cuda/threadblock_swizzle.h>
#include <tl_templates/cuda/debug.h>
#ifdef ENABLE_BF16
#include <tl_templates/cuda/cuda_bf16_fallbacks.cuh>
#endif

extern "C" __global__ void main_kernel(const float* __restrict__ X, float* __restrict__ Y);
extern "C" __global__ void __launch_bounds__(256, 1) main_kernel(const float* __restrict__ X, float* __restrict__ Y) {
  float values[4];
  float2 result_pack[1];
  float result[1];
  extern __shared__ __align__(1024) float workspace[];
  *(float4*)(values + 0) = *(float4*)(X + ((((int)blockIdx.x) * 1024) + (((int)threadIdx.x) * 4)));
  float broadcast_var = -CUDART_INF_F;
  result_pack[0] = make_float2(broadcast_var, broadcast_var);
  #pragma unroll
  for (int rv = 0; rv < 2; ++rv) {
    result_pack[0] = tl::max2(result_pack[0], *(float2*)(values + (rv * 2)));
  }
  result[0] = max((result_pack[0]).x, (result_pack[0]).y);
  result[0] = tl::AllReduce<tl::MaxOp, 256, 1, 0, tl::NamedBarrier<256>>::run(result[0], (&(workspace[0])));
  Y[((int)blockIdx.x)] = result[0];
}

