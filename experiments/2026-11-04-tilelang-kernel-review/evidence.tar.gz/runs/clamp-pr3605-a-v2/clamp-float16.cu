#if defined(_MSC_VER) && !defined(__clang__) && _MSC_VER < 1940
#define _tl_orig_alignas alignas
#define alignas(N) _tl_orig_alignas((N) <= 64 ? (N) : 64)
#include <cuda.h>
#undef alignas
#define alignas _tl_orig_alignas
#endif
#include <tl_templates/cuda/math.h>
#include <tl_templates/cuda/reduce.h>
#include <tl_templates/cuda/scan.h>
#include <tl_templates/cuda/ldsm.h>
#include <tl_templates/cuda/threadblock_swizzle.h>
#include <tl_templates/cuda/debug.h>
#ifdef ENABLE_BF16
#include <tl_templates/cuda/cuda_bf16_fallbacks.cuh>
#endif

extern "C" __global__ void main_kernel(const half_t* __restrict__ X, half_t* __restrict__ Y);
extern "C" __global__ void __launch_bounds__(128, 1) main_kernel(const half_t* __restrict__ X, half_t* __restrict__ Y) {
  half_t broadcast_var = half_t(0x1.cp+2f/*7.000000e+00*/);
  uint1 __1;
    uint1 clamp_symmetric_arg = *(uint1*)(X + ((((int)blockIdx.x) * 256) + (((int)threadIdx.x) * 2)));
    uint1 v_ = make_uint1(__pack_half2(broadcast_var, broadcast_var));
    *(uint1*)(&(__1.x)) = tl::to_uint1(tl::clamp_symmetric2(tl::from_uint1<__half2>(*(uint1*)(&(clamp_symmetric_arg.x))), tl::from_uint1<__half2>(*(uint1*)(&(v_.x)))));
  *(uint1*)(Y + ((((int)blockIdx.x) * 256) + (((int)threadIdx.x) * 2))) = __1;
}

