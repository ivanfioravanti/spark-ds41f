#if defined(_MSC_VER) && !defined(__clang__) && _MSC_VER < 1940
#define _tl_orig_alignas alignas
#define alignas(N) _tl_orig_alignas((N) <= 64 ? (N) : 64)
#include <cuda.h>
#undef alignas
#define alignas _tl_orig_alignas
#endif
#include <tl_templates/cuda/math.h>
#include <tl_templates/cuda/reduce.h>
#include <tl_templates/cuda/scan.h>
#include <tl_templates/cuda/ldsm.h>
#include <tl_templates/cuda/threadblock_swizzle.h>
#include <tl_templates/cuda/debug.h>
#ifdef ENABLE_BF16
#include <tl_templates/cuda/cuda_bf16_fallbacks.cuh>
#endif

extern "C" __global__ void main_kernel(const float* __restrict__ X, float* __restrict__ Y);
extern "C" __global__ void __launch_bounds__(128, 1) main_kernel(const float* __restrict__ X, float* __restrict__ Y) {
  float broadcast_var = 0x1.cp+2f/*7.000000e+00*/;
  float2 __1;
    float2 clamp_symmetric_arg = *(float2*)(X + ((((int)blockIdx.x) * 256) + (((int)threadIdx.x) * 2)));
    float2 v_ = make_float2(broadcast_var, broadcast_var);
    __1.x = tl::clamp_symmetric(clamp_symmetric_arg.x, v_.x);
    __1.y = tl::clamp_symmetric(clamp_symmetric_arg.y, v_.y);
  *(float2*)(Y + ((((int)blockIdx.x) * 256) + (((int)threadIdx.x) * 2))) = __1;
}

