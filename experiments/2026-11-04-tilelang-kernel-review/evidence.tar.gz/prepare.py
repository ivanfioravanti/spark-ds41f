from pathlib import Path
import subprocess,json,datetime
base=Path.home()/"spark-lab/tilelang-review-20261104"
def run(args,cwd=None):
 print("COMMAND",json.dumps(args),flush=True)
 subprocess.run(args,cwd=cwd,check=True)
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
(base/"prepare-start.json").write_text(json.dumps({"started_utc":now(),"gpu_devices":False,"serving_operations":False},indent=2))
dep=base/"deployment"
if not dep.exists():
 run(["git","init","--quiet",str(dep)])
 run(["git","remote","add","deployment","https://github.com/christopherowen/spark-ds41f.git"],dep)
 run(["git","sparse-checkout","init","--cone"],dep)
 run(["git","sparse-checkout","set","experiments/2026-11-04-tilelang-refresh/tilelang"],dep)
 run(["git","fetch","--quiet","--depth","1","--filter=blob:none","deployment","e33d1e0223b7346b821a9201d5c67c3745c0151a"],dep)
 run(["git","switch","--detach","FETCH_HEAD"],dep)
source=base/"tilelang"
if not source.exists():
 run(["git","clone","--filter=blob:none","--no-checkout","--origin","upstream","https://github.com/tile-ai/tilelang.git",str(source)])
 run(["git","remote","add","origin","https://github.com/christopherowen/tilelang.git"],source)
 run(["git","switch","--create","review/base","2123e412ce2217b324c50c4ec967213906456ac5"],source)
 series=dep/"experiments/2026-11-04-tilelang-refresh/tilelang/series"
 for line in series.read_text().splitlines():
  if line and not line.startswith("#"):
   run(["git","-c","user.name=Christopher Owen","-c","user.email=3221756+christopherowen@users.noreply.github.com","am","--committer-date-is-author-date",str(series.parent/line)],source)
 run(["git","submodule","update","--init","--recursive","--depth","1","--jobs","4"],source)
head=subprocess.check_output(["git","rev-parse","HEAD"],cwd=source,text=True).strip()
tree=subprocess.check_output(["git","rev-parse","HEAD^{tree}"],cwd=source,text=True).strip()
assert head=="b26f48b85790b832993f2c9d240dc3c39d6075e8",head
assert tree=="971d99a61b44a702110cf98bef56ee1a44ddeaf1",tree
run(["git","diff","--check","2123e412","HEAD"],source)
(base/"prepared.json").write_text(json.dumps({"ended_utc":now(),"head":head,"tree":tree},indent=2)+"\n")
print("PREPARED",head,tree,flush=True)
